from flask import Flask, request, render_template_string
import base64

app = Flask(__name__)

CSS = """
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        color: #333;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 600px;
        margin: 50px auto;
        background-color: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    h1 {
        text-align: center;
        color: #4CAF50;
    }
    label {
        font-size: 1.1em;
        margin-bottom: 10px;
        display: block;
    }
    input[type="text"] {
        width: 100%;
        padding: 10px;
        margin: 10px 0 20px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 1em;
    }
    button {
        background-color: #4CAF50;
        color: white;
        border: none;
        padding: 10px 20px;
        font-size: 1.1em;
        cursor: pointer;
        border-radius: 4px;
        transition: background-color 0.3s;
    }
    button:hover {
        background-color: #45a049;
    }
    .result {
        margin-top: 30px;
        padding: 15px;
        background-color: #f9f9f9;
        border: 1px solid #ddd;
        border-radius: 5px;
        color: #333;
        text-align: center;
    }
    .error {
        color: red;
    }
    a {
        display: block;
        text-align: center;
        margin-top: 20px;
        font-size: 1.1em;
        color: #4CAF50;
        text-decoration: none;
    }
    a:hover {
        text-decoration: underline;
    }
"""

@app.route('/')
def home():
    return render_template_string(f"""
        <!-- Oh look, it's Jinja2 - the "brilliant" template engine that lets you embed Python-like code in HTML! 
             Want to know a secret? never mind but oh yeah its used for template , have fun! -->
        <style>{CSS}</style>
        <div class="container">
            <h1>Base64 Decoder</h1>
            <form action="/decode" method="post">
                <label for="b64input">Enter base64 encoded string:</label>
                <input type="text" name="b64input" id="b64input" required>
                <button type="submit">Decode!</button>
            </form>
        </div>
    """)

@app.route('/decode', methods=['POST'])
def decode():
    b64_input = request.form.get('b64input', '')
    
    try:
        decoded_bytes = base64.b64decode(b64_input)
        decoded_string = decoded_bytes.decode('utf-8')

        # Allow SSTI by not escaping the decoded string
        result = f"Decoded string: {decoded_string}"

    except (base64.binascii.Error, TypeError) as e:
        result = f"Error: Invalid base64 input. {str(e)}"
    
    except Exception as e:
        result = f"Unexpected error: {str(e)}"
    
    return render_template_string(f"""
        <style>{CSS}</style>
        <div class="container">
            <h1>Base64 Decoding Result</h1>
            <div class="result">
                <p>{result}</p>
            </div>
            <a href="/">Go Back</a>
        </div>
    """)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=1234, debug=True)