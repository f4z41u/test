
const encodedSecret = "X2gxZGQzbn0=";

function checkCredentials() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    
    if (username === 'admin' && password === 'admin123') {
        
        console.log("Good job! Now try to find all parts of the flag!");
        console.log("Part 3 of the flag is base64 encoded above!");
    } else {
        alert("Invalid credentials!");
    }
}


fetch('/nonexistent.txt')
    .then(response => console.log('Looking in the wrong place!'))
    .catch(() => {
        
    });
